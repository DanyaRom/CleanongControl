import Foundation
import SwiftUI

struct CleaningTask: Identifiable, Hashable, Codable {
    let id: UUID
    let title: String
    var isCompleted: Bool
    var completionTime: Date?
    var photoURLString: String?
    
    var photoURL: URL? {
        get {
            if let urlString = photoURLString {
                return URL(string: urlString)
            }
            return nil
        }
        set {
            photoURLString = newValue?.absoluteString
        }
    }
    
    init(id: UUID = UUID(), title: String, isCompleted: Bool = false, completionTime: Date? = nil, photoURL: URL? = nil) {
        self.id = id
        self.title = title
        self.isCompleted = isCompleted
        self.completionTime = completionTime
        self.photoURLString = photoURL?.absoluteString
    }
    
    enum CodingKeys: String, CodingKey {
        case id, title, isCompleted, completionTime, photoURLString
    }
}
