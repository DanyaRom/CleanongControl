import SwiftUI

struct CompletedShiftsView: View {
    @ObservedObject var store: CleaningStore
    @State private var showingDeleteAlert = false
    @State private var shiftToDelete: CompletedShift?
    @State private var indexSetToDelete: IndexSet?
    
    var body: some View {
        NavigationView {
            Group {
                if store.completedShifts.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "clock.arrow.circlepath")
                            .font(.system(size: 70))
                            .foregroundColor(.blue.opacity(0.7))
                            .padding()
                            .background(
                                Circle()
                                    .fill(Color.blue.opacity(0.1))
                                    .frame(width: 150, height: 150)
                            )
                        
                        Text("Нет завершенных смен")
                            .font(.title2)
                            .fontWeight(.medium)
                            .foregroundColor(.secondary)
                        
                        Text("Завершенные смены будут отображаться здесь")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 40)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
                } else {
                    List {
                        ForEach(store.completedShifts) { shift in
                            NavigationLink(destination: CompletedShiftDetailView(shift: shift)) {
                                CompletedShiftRow(shift: shift)
                            }
                            .contextMenu {
                                Button(action: {
                                    shiftToDelete = shift
                                    if let index = store.completedShifts.firstIndex(where: { $0.id == shift.id }) {
                                        indexSetToDelete = IndexSet([index])
                                        showingDeleteAlert = true
                                    }
                                }) {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                            .onLongPressGesture {
                                if let index = store.completedShifts.firstIndex(where: { $0.id == shift.id }) {
                                    shiftToDelete = shift
                                    indexSetToDelete = IndexSet([index])
                                    showingDeleteAlert = true
                                }
                            }
                        }
                        .onDelete { indexSet in
                            indexSetToDelete = indexSet
                            showingDeleteAlert = true
                        }
                    }
                    .listStyle(InsetGroupedListStyle())
                    .alert(isPresented: $showingDeleteAlert) {
                        Alert(
                            title: Text("Удалить смену"),
                            message: Text("Вы уверены, что хотите удалить эту смену? Это действие нельзя отменить."),
                            primaryButton: .destructive(Text("Удалить")) {
                                if let indexSet = indexSetToDelete {
                                    store.deleteCompletedShift(at: indexSet)
                                    indexSetToDelete = nil
                                    shiftToDelete = nil
                                }
                            },
                            secondaryButton: .cancel(Text("Отмена")) {
                                indexSetToDelete = nil
                                shiftToDelete = nil
                            }
                        )
                    }
                }
            }
            .navigationTitle("Закрытые смены")
        }
    }
}

struct CompletedShiftRow: View {
    let shift: CompletedShift
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Image(systemName: "person.circle.fill")
                    .font(.title2)
                    .foregroundColor(.blue)
                
                Text(shift.shiftInfo.employeeName)
                    .font(.headline)
                
                Spacer()
                
                Image(systemName: "checkmark.seal.fill")
                    .foregroundColor(.green)
            }
            
            Divider()
            
            HStack {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Дата смены:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text(formatDate(shift.shiftInfo.date))
                        .font(.subheadline)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 5) {
                    Text("Завершено:")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    Text(formatDateTime(shift.completionDate))
                        .font(.subheadline)
                }
            }
            
            HStack {
                let totalTasks = shift.zones.reduce(0) { $0 + $1.tasks.count }
                let completedTasks = shift.zones.reduce(0) { $0 + $1.tasks.filter { $0.isCompleted }.count }
                
                Text("\(completedTasks)/\(totalTasks) задач выполнено")
                    .font(.caption)
                    .padding(.vertical, 5)
                    .padding(.horizontal, 10)
                    .background(
                        Capsule()
                            .fill(Color.green.opacity(0.2))
                    )
                    .foregroundColor(.green)
                
                Spacer()
                
                Image(systemName: "chevron.right")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
        }
        .padding(.vertical, 8)
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func formatDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct CompletedShiftDetailView: View {
    let shift: CompletedShift
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Информация о смене
                VStack(spacing: 15) {
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                        
                        Text(shift.shiftInfo.employeeName)
                            .font(.title2)
                            .bold()
                        
                        Spacer()
                    }
                    
                    Divider()
                    
                    HStack {
                        VStack(alignment: .leading, spacing: 8) {
                            Label {
                                Text("Дата смены")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            } icon: {
                                Image(systemName: "calendar")
                                    .foregroundColor(.blue)
                            }
                            
                            Text(formatDate(shift.shiftInfo.date))
                                .font(.headline)
                        }
                        
                        Spacer()
                        
                        VStack(alignment: .trailing, spacing: 8) {
                            Label {
                                Text("Завершено")
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            } icon: {
                                Image(systemName: "clock")
                                    .foregroundColor(.green)
                            }
                            
                            Text(formatDateTime(shift.completionDate))
                                .font(.headline)
                        }
                    }
                    
                    let totalTasks = shift.zones.reduce(0) { $0 + $1.tasks.count }
                    let completedTasks = shift.zones.reduce(0) { $0 + $1.tasks.filter { $0.isCompleted }.count }
                    
                    HStack {
                        Text("Выполнено задач:")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("\(completedTasks) из \(totalTasks)")
                            .font(.headline)
                            .foregroundColor(.green)
                    }
                }
                .padding()
                .background(
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color(.systemBackground))
                        .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
                )
                .padding(.horizontal)
                
                // Список зон и задач
                ForEach(shift.zones) { zone in
                    VStack(alignment: .leading, spacing: 15) {
                        HStack {
                            ZStack {
                                Circle()
                                    .fill(getZoneColor(zone).opacity(0.2))
                                    .frame(width: 40, height: 40)
                                
                                Image(systemName: zone.icon)
                                    .font(.headline)
                                    .foregroundColor(getZoneColor(zone))
                            }
                            
                            Text(zone.name)
                                .font(.headline)
                            
                            Spacer()
                            
                            let completedCount = zone.tasks.filter { $0.isCompleted }.count
                            Text("\(completedCount)/\(zone.tasks.count)")
                                .font(.subheadline)
                                .foregroundColor(completedCount == zone.tasks.count ? .green : .secondary)
                        }
                        
                        Divider()
                        
                        ForEach(zone.tasks) { task in
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(task.title)
                                        .strikethrough(task.isCompleted)
                                        .foregroundColor(task.isCompleted ? .secondary : .primary)
                                    
                                    if let completionTime = task.completionTime {
                                        Text("Выполнено: \(formatTime(completionTime))")
                                            .font(.caption)
                                            .foregroundColor(.green)
                                    }
                                }
                                
                                Spacer()
                                
                                if task.isCompleted {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.green)
                                } else {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.red)
                                }
                            }
                            .padding(.vertical, 5)
                        }
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(.systemBackground))
                            .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
                    )
                    .padding(.horizontal)
                }
            }
            .padding(.vertical)
        }
        .navigationTitle("Детали смены")
        .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        return formatter.string(from: date)
    }
    
    private func formatDateTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func getZoneColor(_ zone: Zone) -> Color {
        switch zone.colorName {
        case "blue": return .blue
        case "green": return .green
        case "purple": return .purple
        case "red": return .red
        default: return .blue
        }
    }
}
