import SwiftUI

@main
struct CleaningControlApp: App {
    @StateObject private var store = CleaningStore()
    
    var body: some Scene {
        WindowGroup {
            MainTabView(store: store)
        }
    }
}
