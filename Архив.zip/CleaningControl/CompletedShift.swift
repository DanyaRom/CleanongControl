import Foundation

struct CompletedShift: Identifiable, Codable {
    let id: UUID
    let shiftInfo: ShiftInfo
    let zones: [Zone]
    let completionDate: Date
    
    init(id: UUID = UUID(), shiftInfo: ShiftInfo, zones: [Zone], completionDate: Date) {
        self.id = id
        self.shiftInfo = shiftInfo
        self.zones = zones
        self.completionDate = completionDate
    }
}
