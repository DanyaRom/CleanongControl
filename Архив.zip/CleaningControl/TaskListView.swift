import SwiftUI
import PhotosUI

struct TaskListView: View {
    let zone: Zone
    let zoneIndex: Int
    @ObservedObject var store: CleaningStore
    @State private var showingImagePicker = false
    @State private var selectedImage: UIImage?
    @State private var selectedTaskForImage: Int?
    @State private var showingFullScreenImage = false
    
    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                ForEach(Array(zone.tasks.enumerated()), id: \.element.id) { index, task in
                    TaskRow(task: task, zoneIndex: zoneIndex, taskIndex: index, store: store)
                        .transition(.asymmetric(
                            insertion: .scale.combined(with: .opacity),
                            removal: .scale.combined(with: .opacity)
                        ))
                        .animation(.spring(response: 0.3, dampingFraction: 0.8), value: task.isCompleted)
                }
            }
            .padding(.vertical)
        }
        .background(Color(.systemGroupedBackground))
        .navigationTitle(zone.name)
        .navigationBarTitleDisplayMode(.large)
    }
}

struct TaskRow: View {
    let task: CleaningTask
    let zoneIndex: Int
    let taskIndex: Int
    @ObservedObject var store: CleaningStore
    @State private var showingImagePicker = false
    @State private var showingFullScreenImage = false
    @State private var showingDeleteAlert = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 15) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(task.title)
                        .font(.system(size: 17, weight: .semibold))
                        .strikethrough(task.isCompleted)
                        .foregroundColor(task.isCompleted ? .secondary : .primary)
                    
                    if let completionTime = task.completionTime {
                        HStack(spacing: 4) {
                            Image(systemName: "checkmark.circle.fill")
                                .font(.caption)
                            Text("Выполнено: \(formatTime(completionTime))")
                                .font(.system(size: 13, weight: .medium))
                        }
                        .foregroundColor(.green)
                        .opacity(0.9)
                    }
                }
                
                Spacer()
                
                Button(action: {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                        store.toggleTask(zoneIndex: zoneIndex, taskIndex: taskIndex)
                        let generator = UIImpactFeedbackGenerator(style: .medium)
                        generator.impactOccurred()
                    }
                }) {
                    ZStack {
                        Circle()
                            .fill(task.isCompleted ? Color.green.opacity(0.2) : Color.gray.opacity(0.1))
                            .frame(width: 36, height: 36)
                        
                        Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 24, weight: .semibold))
                            .foregroundColor(task.isCompleted ? .green : .gray.opacity(0.5))
                    }
                }
            }
            
            if !task.isCompleted {
                if let photoURL = task.photoURL, let image = loadImageFromURL(photoURL) {
                    Button(action: {
                        showingFullScreenImage = true
                    }) {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                            .frame(height: 150)
                            .clipped()
                            .cornerRadius(16)
                            .overlay(
                                RoundedRectangle(cornerRadius: 16)
                                    .stroke(Color.gray.opacity(0.2), lineWidth: 1)
                            )
                            .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 1)
                    }
                    .onLongPressGesture(minimumDuration: 0.5) {
                        let generator = UIImpactFeedbackGenerator(style: .medium)
                        generator.impactOccurred()
                        showingDeleteAlert = true
                    }
                    .alert(isPresented: $showingDeleteAlert) {
                        Alert(
                            title: Text("Удалить фото"),
                            message: Text("Вы уверены, что хотите удалить фото?"),
                            primaryButton: .destructive(Text("Удалить")) {
                                withAnimation {
                                    if let photoURL = task.photoURL {
                                        do {
                                            try FileManager.default.removeItem(at: photoURL)
                                            var updatedTasks = store.zones[zoneIndex].tasks
                                            updatedTasks[taskIndex].photoURL = nil
                                            store.zones[zoneIndex].tasks = updatedTasks
                                        } catch {
                                            print("Error removing photo: \(error)")
                                        }
                                    }
                                }
                            },
                            secondaryButton: .cancel(Text("Отмена"))
                        )
                    }
                    .sheet(isPresented: $showingFullScreenImage) {
                        FullScreenImageView(image: image)
                    }
                } else {
                    Button(action: {
                        showingImagePicker = true
                        let generator = UIImpactFeedbackGenerator(style: .light)
                        generator.impactOccurred()
                    }) {
                        HStack(spacing: 10) {
                            Image(systemName: "camera")
                                .font(.system(size: 16, weight: .medium))
                            Text("Добавить фото")
                                .font(.system(size: 16, weight: .medium))
                        }
                        .foregroundColor(.white)
                        .padding(.vertical, 10)
                        .padding(.horizontal, 16)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.blue]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                        )
                        .shadow(color: Color.blue.opacity(0.2), radius: 4, x: 0, y: 2)
                    }
                    .frame(maxWidth: .infinity, alignment: .center)
                }
            }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 16)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.03), radius: 3, x: 0, y: 1)
                .shadow(color: Color.black.opacity(0.03), radius: 8, x: 0, y: 4)
        )
        .padding(.horizontal, 16)
        .sheet(isPresented: $showingImagePicker) {
            ImagePicker(zoneIndex: zoneIndex, taskIndex: taskIndex, store: store)
        }
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    private func loadImageFromURL(_ url: URL) -> UIImage? {
        do {
            let imageData = try Data(contentsOf: url)
            return UIImage(data: imageData)
        } catch {
            print("Error loading image: \(error)")
            return nil
        }
    }
}

struct FullScreenImageView: View {
    let image: UIImage
    @Environment(\.presentationMode) var presentationMode
    @State private var scale: CGFloat = 0.9
    @State private var opacity: Double = 0
    
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            Image(uiImage: image)
                .resizable()
                .scaledToFit()
                .edgesIgnoringSafeArea(.all)
                .scaleEffect(scale)
                .opacity(opacity)
            
            VStack {
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            scale = 0.9
                            opacity = 0
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                            presentationMode.wrappedValue.dismiss()
                        }
                    }) {
                        Image(systemName: "xmark.circle.fill")
                            .font(.title)
                            .foregroundColor(.white)
                            .padding()
                            .background(Circle().fill(Color.black.opacity(0.5)))
                    }
                    .padding()
                }
                Spacer()
            }
        }
        .onAppear {
            withAnimation(.easeOut(duration: 0.2)) {
                scale = 1
                opacity = 1
            }
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    let zoneIndex: Int
    let taskIndex: Int
    @ObservedObject var store: CleaningStore
    @Environment(\.presentationMode) var presentationMode
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var config = PHPickerConfiguration()
        config.selectionLimit = 1
        config.filter = .images
        
        let picker = PHPickerViewController(configuration: config)
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            parent.presentationMode.wrappedValue.dismiss()
            
            guard let provider = results.first?.itemProvider else { return }
            
            if provider.canLoadObject(ofClass: UIImage.self) {
                provider.loadObject(ofClass: UIImage.self) { image, error in
                    if let error = error {
                        print("Error loading image: \(error.localizedDescription)")
                        return
                    }
                    
                    guard let image = image as? UIImage else { return }
                    
                    DispatchQueue.main.async {
                        if let data = image.jpegData(compressionQuality: 0.8) {
                            let filename = UUID().uuidString + ".jpg"
                            if let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first?.appendingPathComponent(filename) {
                                do {
                                    try data.write(to: url)
                                    self.parent.store.addPhotoToTask(
                                        zoneIndex: self.parent.zoneIndex,
                                        taskIndex: self.parent.taskIndex,
                                        photoURL: url
                                    )
                                } catch {
                                    print("Error saving image: \(error.localizedDescription)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(
            roundedRect: rect,
            byRoundingCorners: corners,
            cornerRadii: CGSize(width: radius, height: radius)
        )
        return Path(path.cgPath)
    }
}

extension UIImage {
    func resized(to size: CGSize) -> UIImage {
        return UIGraphicsImageRenderer(size: size).image { _ in
            draw(in: CGRect(origin: .zero, size: size))
        }
    }
    
    func compressedData(quality: CGFloat = 0.5) -> Data? {
        return self.jpegData(compressionQuality: quality)
    }
}
