import SwiftUI

struct WelcomeView: View {
    @ObservedObject var store: CleaningStore
    @State private var showingAlert = false
    @State private var showingEmployeeSheet = false
    @State private var selectedEmployeeIndex: Int?
    @State private var customEmployeeName = ""
    
    var body: some View {
        ScrollView {
            VStack(spacing: 35) {
                // Заголовок с улучшенным стилем
                Text("Контроль Уборки")
                    .font(.system(size: 38, weight: .bold))
                    .foregroundColor(.primary)
                    .padding(.top, 30)
                    .shadow(color: Color.black.opacity(0.1), radius: 1, x: 0, y: 1)
                
                // Улучшенная иконка с более выразительными эффектами
                Image(systemName: "sparkles")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 85, height: 85)
                    .foregroundColor(.white)
                    .padding(35)
                    .background(
                        ZStack {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [Color.blue.opacity(0.7), Color.blue]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                            
                            // Добавляем внутреннее свечение
                            Circle()
                                .stroke(Color.white.opacity(0.6), lineWidth: 2)
                                .blur(radius: 1)
                                .padding(4)
                            
                            Circle()
                                .stroke(Color.white, lineWidth: 2)
                                .padding(3)
                        }
                    )
                    .shadow(color: Color.blue.opacity(0.5), radius: 20, x: 0, y: 10)
                    .padding(.bottom, 15)
                
                // Форма для начала смены с улучшенным дизайном
                VStack(alignment: .leading, spacing: 25) {
                    Text("Начать новую смену")
                        .font(.title3)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .padding(.bottom, 5)
                    
                    // Выбор даты с улучшенным стилем
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Дата")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        DatePicker("", selection: $store.shiftInfo.date, displayedComponents: .date)
                            .datePickerStyle(CompactDatePickerStyle())
                            .labelsHidden()
                            .padding(14)
                            .background(
                                RoundedRectangle(cornerRadius: 14)
                                    .fill(Color(.systemBackground))
                                    .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                            )
                    }
                    
                    // Выбор сотрудника с улучшенным стилем
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Сотрудник")
                            .font(.headline)
                            .foregroundColor(.secondary)
                        
                        if let index = selectedEmployeeIndex {
                            // Показываем выбранного сотрудника
                            HStack {
                                Text(store.employees[index].name)
                                    .foregroundColor(.primary)
                                    .fontWeight(.medium)
                                
                                Spacer()
                                
                                Button(action: {
                                    selectedEmployeeIndex = nil
                                    customEmployeeName = ""
                                }) {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundColor(.gray)
                                        .font(.system(size: 18))
                                }
                            }
                            .padding(14)
                            .background(
                                RoundedRectangle(cornerRadius: 14)
                                    .fill(Color(.systemBackground))
                                    .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                            )
                        } else {
                            // Показываем поле для ввода имени
                            TextField("Введите имя сотрудника", text: $customEmployeeName)
                                .padding(14)
                                .background(
                                    RoundedRectangle(cornerRadius: 14)
                                        .fill(Color(.systemBackground))
                                        .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                                )
                        }
                        
                        // Кнопка выбора из списка с улучшенным стилем
                        Button(action: {
                            showingEmployeeSheet = true
                        }) {
                            HStack {
                                Image(systemName: "person.crop.circle")
                                    .font(.system(size: 16))
                                Text("Выбрать из списка")
                                    .fontWeight(.medium)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                            .padding(14)
                            .background(
                                RoundedRectangle(cornerRadius: 14)
                                    .fill(Color(.systemBackground))
                                    .shadow(color: Color.black.opacity(0.08), radius: 6, x: 0, y: 3)
                            )
                        }
                        .foregroundColor(.primary)
                    }
                }
                .padding(25)
                .background(
                    RoundedRectangle(cornerRadius: 24)
                        .fill(Color(.secondarySystemBackground))
                        .shadow(color: Color.black.opacity(0.12), radius: 15, x: 0, y: 8)
                )
                .padding(.horizontal)
                
                // Улучшенная кнопка открытия смены
                Button(action: {
                    if let index = selectedEmployeeIndex {
                        store.shiftInfo.employeeName = store.employees[index].name
                        store.startShift()
                    } else if !customEmployeeName.isEmpty {
                        store.shiftInfo.employeeName = customEmployeeName
                        // Добавляем нового сотрудника в список
                        store.addEmployee(name: customEmployeeName)
                        store.startShift()
                    } else {
                        showingAlert = true
                    }
                }) {
                    Text("Открыть смену")
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 18)
                        .background(
                            ZStack {
                                RoundedRectangle(cornerRadius: 18)
                                    .fill(
                                        LinearGradient(
                                            gradient: Gradient(colors: [Color.blue.opacity(0.9), Color.blue]),
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                
                                // Добавляем эффект свечения по краям
                                RoundedRectangle(cornerRadius: 18)
                                    .stroke(Color.white.opacity(0.3), lineWidth: 1)
                                    .blendMode(.overlay)
                            }
                        )
                        .shadow(color: Color.blue.opacity(0.4), radius: 10, x: 0, y: 6)
                        .padding(.top, 15)
                }
                .padding(.horizontal)
                .alert(isPresented: $showingAlert) {
                    Alert(
                        title: Text("Ошибка"),
                        message: Text("Пожалуйста, введите имя сотрудника"),
                        dismissButton: .default(Text("OK"))
                    )
                }
                .sheet(isPresented: $showingEmployeeSheet) {
                    EmployeeSelectionView(
                        store: store,
                        selectedEmployeeIndex: $selectedEmployeeIndex,
                        showingSheet: $showingEmployeeSheet
                    )
                }
                
                Spacer()
            }
            .padding(.bottom, 30)
        }
        .background(Color(.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }
}

struct EmployeeSelectionView: View {
    @ObservedObject var store: CleaningStore
    @Binding var selectedEmployeeIndex: Int?
    @Binding var showingSheet: Bool
    @State private var newEmployeeName = ""
    @State private var showingAddAlert = false
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(Array(store.employees.enumerated()), id: \.element.id) { index, employee in
                        Button(action: {
                            selectedEmployeeIndex = index
                            showingSheet = false
                        }) {
                            // ... rest of the button content ...
                            HStack {
                                Text(employee.name)
                                    .foregroundColor(.primary)
                                
                                Spacer()
                                
                                if selectedEmployeeIndex == index {
                                    Image(systemName: "checkmark")
                                        .foregroundColor(.blue)
                                }
                            }
                        }
                    }
                    .onDelete(perform: store.deleteEmployee)
                }
                
                Divider()
                
                HStack {
                    TextField("Имя нового сотрудника", text: $newEmployeeName)
                        .padding(10)
                        .background(
                            RoundedRectangle(cornerRadius: 8)
                                .fill(Color(.systemGray6))
                        )
                    
                    Button(action: {
                        if !newEmployeeName.isEmpty {
                            store.addEmployee(name: newEmployeeName)
                            newEmployeeName = ""
                        } else {
                            showingAddAlert = true
                        }
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                }
                .padding()
            }
            .navigationTitle("Выберите сотрудника")
            .navigationBarItems(
                trailing: Button("Закрыть") {
                    showingSheet = false
                }
            )
            .alert(isPresented: $showingAddAlert) {
                Alert(
                    title: Text("Ошибка"),
                    message: Text("Введите имя сотрудника"),
                    dismissButton: .default(Text("OK"))
                )
            }
        }
    }
}
