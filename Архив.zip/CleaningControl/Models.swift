import Foundation
import SwiftUI

struct ShiftInfo: Codable {
    var employeeName: String = ""
    var date: Date = Date()
    var isStarted: Bool = false
    var isCompleted: Bool = false
    var completionDate: Date?
}

struct CleaningTask: Identifiable, Codable {
    var id = UUID()
    var title: String
    var isCompleted: Bool = false
    var completionTime: Date?
    var photoURL: URL?
    
    enum CodingKeys: String, CodingKey {
        case id, title, isCompleted, completionTime, photoURL
    }
}

enum ZoneColor: String, Codable, CaseIterable {
    case blue, green, purple, red
}

struct Zone: Identifiable, Codable {
    var id = UUID()
    var name: String
    var icon: String
    var color: ZoneColor
    var tasks: [CleaningTask]
    
    // Добавляем кодирование/декодирование для color
    enum CodingKeys: String, CodingKey {
        case id, name, icon, color, tasks
    }
}

struct Employee: Identifiable, Codable {
    var id = UUID()
    var name: String
}

struct CompletedShift: Identifiable, Codable {
    var id = UUID()
    var shiftInfo: ShiftInfo
    var zones: [Zone]
    var completionDate: Date
}
