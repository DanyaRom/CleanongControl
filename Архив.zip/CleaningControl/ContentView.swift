import SwiftUI

struct ContentView: View {
    @StateObject private var store = CleaningStore()
    
    var body: some View {
        NavigationView {
            List {
                ForEach(Array(store.zones.enumerated()), id: \.element.id) { zoneIndex, zone in
                    NavigationLink(destination: TaskListView(zone: zone, zoneIndex: zoneIndex, store: store)) {
                        Text(zone.name)
                    }
                }
            }
            .navigationTitle("Контроль Уборки")
        }
    }
}

struct ContentTaskRow: View {
    let task: CleaningTask
    let index: Int
    @ObservedObject var store: CleaningStore
    let zoneIndex: Int
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 8) {
                Text(task.title)
                    .font(.headline)
                
                if let completionTime = task.completionTime {
                    Text("Выполнено: \(formatTime(completionTime))")
                        .font(.caption)
                        .foregroundColor(.green)
                }
            }
            
            Spacer()
            
            Button(action: {
                store.toggleTask(zoneIndex: zoneIndex, taskIndex: index)
            }) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .resizable()
                    .frame(width: 24, height: 24)
                    .foregroundColor(task.isCompleted ? .green : .gray)
            }
        }
        .padding(.vertical, 8)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
