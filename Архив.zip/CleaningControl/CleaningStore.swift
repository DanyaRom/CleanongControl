import Foundation
import SwiftUI

class CleaningStore: ObservableObject {
    @Published var shiftInfo = ShiftInfo()
    @Published var zones: [Zone] = [
        Zone(
            name: "Бар",
            icon: "wineglass",
            color: .blue,
            tasks: [
                CleaningTask(title: "Намыть посуду"),
                CleaningTask(title: "Помыть кальяны"),
                CleaningTask(title: "Протереть все поверхности"),
                CleaningTask(title: "Помыть стойку с углями"),
                CleaningTask(title: "Помыть под раковиной")
            ]
        ),
        Zone(
            name: "Зал",
            icon: "table.furniture",
            color: .green,
            tasks: [
                CleaningTask(title: "Подмести и помыть полы"),
                CleaningTask(title: "Протереть столы"),
                CleaningTask(title: "Проверить закрыты ли окна"),
                CleaningTask(title: "Выключить все устройства")
            ]
        ),
        Zone(
            name: "Туалет",
            icon: "toilet",
            color: .purple,
            tasks: [
                CleaningTask(title: "Намыть туалет"),
                CleaningTask(title: "Протереть все в туалете")
            ]
        ),
        Zone(
            name: "Завершение смены",
            icon: "checkmark.seal",
            color: .red,
            tasks: [
                CleaningTask(title: "Проверить и закрыть кассу"),
                CleaningTask(title: "Заполнить холодильник"),
                CleaningTask(title: "Выключить свет"),
                CleaningTask(title: "Выключить вытяжки"),
                CleaningTask(title: "Включить сигнализацию"),
                CleaningTask(title: "Ехать спать домой")
            ]
        )
    ]
    
    @Published var completedShifts: [CompletedShift] = []
    @Published var employees: [Employee] = [
        Employee(name: "Александр"),
        Employee(name: "Мария"),
        Employee(name: "Иван"),
        Employee(name: "Елена")
    ]
    @Published var selectedTab: Int = 0
    
    private let completedShiftsKey = "completedShifts"
    private let employeesKey = "employees"
    
    init() {
        loadCompletedShifts()
        loadEmployees()
    }
    
    func toggleTask(zoneIndex: Int, taskIndex: Int) {
        zones[zoneIndex].tasks[taskIndex].isCompleted.toggle()
        zones[zoneIndex].tasks[taskIndex].completionTime = zones[zoneIndex].tasks[taskIndex].isCompleted ? Date() : nil
    }
    
    func startShift() {
        shiftInfo.isStarted = true
    }
    
    func completeShift() {
        shiftInfo.isCompleted = true
        shiftInfo.completionDate = Date()
        
        let completedShift = CompletedShift(
            shiftInfo: shiftInfo,
            zones: zones,
            completionDate: Date()
        )
        
        completedShifts.append(completedShift)
        saveCompletedShifts()
        
        resetShift()
    }
    
    func resetShift() {
        shiftInfo = ShiftInfo()
        
        // Сбросить все задачи
        for zoneIndex in 0..<zones.count {
            for taskIndex in 0..<zones[zoneIndex].tasks.count {
                zones[zoneIndex].tasks[taskIndex].isCompleted = false
                zones[zoneIndex].tasks[taskIndex].completionTime = nil
            }
        }
    }
    
    func isZoneCompleted(_ zone: Zone) -> Bool {
        return zone.tasks.allSatisfy { $0.isCompleted }
    }
    
    func completionPercentage() -> Double {
        let totalTasks = zones.reduce(0) { $0 + $1.tasks.count }
        let completedTasks = zones.reduce(0) { $0 + $1.tasks.filter { $0.isCompleted }.count }
        
        return totalTasks > 0 ? Double(completedTasks) / Double(totalTasks) : 0
    }
    
    func addPhotoToTask(zoneIndex: Int, taskIndex: Int, photoURL: URL) {
        zones[zoneIndex].tasks[taskIndex].photoURL = photoURL
    }
    
    func addEmployee(name: String) {
        let newEmployee = Employee(name: name)
        employees.append(newEmployee)
        saveEmployees()
    }
    
    func deleteEmployee(at indexSet: IndexSet) {
        employees.remove(atOffsets: indexSet)
        saveEmployees()
    }
    
    // Function to delete completed shifts
    func deleteCompletedShift(at indexSet: IndexSet) {
        completedShifts.remove(atOffsets: indexSet)
        saveCompletedShifts()
    }
    
    // Сохранение и загрузка завершенных смен
    private func saveCompletedShifts() {
        do {
            let encoded = try JSONEncoder().encode(completedShifts)
            UserDefaults.standard.set(encoded, forKey: completedShiftsKey)
        } catch {
            print("Ошибка при сохранении смен: \(error)")
        }
    }
    
    private func loadCompletedShifts() {
        if let data = UserDefaults.standard.data(forKey: completedShiftsKey) {
            do {
                completedShifts = try JSONDecoder().decode([CompletedShift].self, from: data)
            } catch {
                print("Ошибка при загрузке смен: \(error)")
                completedShifts = []
            }
        }
    }
    
    // Сохранение и загрузка сотрудников
    private func saveEmployees() {
        do {
            let encoded = try JSONEncoder().encode(employees)
            UserDefaults.standard.set(encoded, forKey: employeesKey)
        } catch {
            print("Ошибка при сохранении сотрудников: \(error)")
        }
    }
    
    private func loadEmployees() {
        if let data = UserDefaults.standard.data(forKey: employeesKey) {
            do {
                employees = try JSONDecoder().decode([Employee].self, from: data)
            } catch {
                print("Ошибка при загрузке сотрудников: \(error)")
                // Оставляем стандартных сотрудников
            }
        }
    }
}
