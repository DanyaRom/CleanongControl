import SwiftUI

struct MainTabView: View {
    @ObservedObject var store: CleaningStore
    
    var body: some View {
        TabView(selection: $store.selectedTab) {
            NavigationView {
                TasksContainerView(store: store)
            }
            .tabItem {
                Label("Задачи", systemImage: "checklist")
            }
            .tag(0)
            
            CompletedShiftsView(store: store)
                .tabItem {
                    Label("Закрытые смены", systemImage: "clock.arrow.circlepath")
                }
                .tag(1)
            
            NavigationView {
                EmployeesView(store: store)
            }
            .tabItem {
                Label("Сотрудники", systemImage: "person.3")
            }
            .tag(2)
        }
    }
}
