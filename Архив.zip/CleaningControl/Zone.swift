import Foundation
import SwiftUI

struct Zone: Identifiable, Hashable, Codable {
    let id: UUID
    let name: String
    let icon: String
    var tasks: [CleaningTask]
    
    // Цвет не может быть напрямую закодирован, поэтому храним его как строку
    let colorName: String
    
    var color: Color {
        switch colorName {
        case "blue": return .blue
        case "green": return .green
        case "purple": return .purple
        case "red": return .red
        default: return .blue
        }
    }
    
    init(id: UUID = UUID(), name: String, icon: String, color: Color, tasks: [CleaningTask]) {
        self.id = id
        self.name = name
        self.icon = icon
        self.tasks = tasks
        
        // Преобразуем Color в строку
        if color == .blue {
            self.colorName = "blue"
        } else if color == .green {
            self.colorName = "green"
        } else if color == .purple {
            self.colorName = "purple"
        } else if color == .red {
            self.colorName = "red"
        } else {
            self.colorName = "blue"
        }
    }
    
    // Добавляем кодирование и декодирование для совместимости
    enum CodingKeys: String, CodingKey {
        case id, name, icon, tasks, colorName
    }
}
