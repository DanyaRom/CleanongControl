import SwiftUI

struct TasksContainerView: View {
    @ObservedObject var store: CleaningStore
    
    var body: some View {
        Group {
            if store.shiftInfo.isStarted {
                ZoneListView(store: store)
            } else {
                WelcomeView(store: store)
            }
        }
    }
}
