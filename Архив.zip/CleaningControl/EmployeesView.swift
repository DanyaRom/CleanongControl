import SwiftUI

struct EmployeesView: View {
    @ObservedObject var store: CleaningStore
    @State private var newEmployeeName = ""
    @State private var showingAlert = false
    
    var body: some View {
        VStack {
            List {
                ForEach(store.employees) { employee in
                    HStack {
                        Image(systemName: "person.circle.fill")
                            .font(.title2)
                            .foregroundColor(.blue)
                            .padding(.trailing, 5)
                        
                        Text(employee.name)
                            .font(.headline)
                    }
                    .padding(.vertical, 8)
                }
                .onDelete(perform: store.deleteEmployee)
            }
            
            VStack(spacing: 15) {
                HStack {
                    TextField("Имя нового сотрудника", text: $newEmployeeName)
                        .padding(12)
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(Color(.systemBackground))
                                .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                        )
                    
                    Button(action: {
                        if !newEmployeeName.isEmpty {
                            store.addEmployee(name: newEmployeeName)
                            newEmployeeName = ""
                        } else {
                            showingAlert = true
                        }
                    }) {
                        Image(systemName: "plus.circle.fill")
                            .font(.title)
                            .foregroundColor(.blue)
                    }
                }
                .padding(.horizontal)
                .padding(.top, 10)
                
                Button(action: {
                    if !newEmployeeName.isEmpty {
                        store.addEmployee(name: newEmployeeName)
                        newEmployeeName = ""
                    } else {
                        showingAlert = true
                    }
                }) {
                    Text("Добавить сотрудника")
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(
                            RoundedRectangle(cornerRadius: 12)
                                .fill(
                                    LinearGradient(
                                        gradient: Gradient(colors: [Color.blue, Color.blue.opacity(0.8)]),
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                        )
                        .shadow(color: Color.blue.opacity(0.3), radius: 5, x: 0, y: 3)
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
            }
            .background(
                RoundedRectangle(cornerRadius: 20)
                    .fill(Color(.secondarySystemBackground))
                    .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: -5)
                    .edgesIgnoringSafeArea(.bottom)
            )
        }
        .navigationTitle("Сотрудники")
        .alert(isPresented: $showingAlert) {
            Alert(
                title: Text("Ошибка"),
                message: Text("Пожалуйста, введите имя сотрудника"),
                dismissButton: .default(Text("OK"))
            )
        }
    }
}
