import Foundation

struct ShiftInfo: Identifiable, Codable {
    let id: UUID
    var date: Date
    var employeeName: String
    var isStarted: Bool
    var isCompleted: Bool
    var completionDate: Date?
    
    init(id: UUID = UUID(), date: Date = Date(), employeeName: String = "", isStarted: Bool = false, isCompleted: Bool = false, completionDate: Date? = nil) {
        self.id = id
        self.date = date
        self.employeeName = employeeName
        self.isStarted = isStarted
        self.isCompleted = isCompleted
        self.completionDate = completionDate
    }
}
