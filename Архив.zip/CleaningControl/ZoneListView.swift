import SwiftUI

struct ZoneListView: View {
    @ObservedObject var store: CleaningStore
    @State private var showingCompleteAlert = false
    
    var body: some View {
        ScrollView {
            VStack(spacing: 25) {
                VStack(spacing: 15) {
                    HStack {
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Привет, \(store.shiftInfo.employeeName)!")
                                .font(.title2)
                                .bold()
                            
                            Text(dateFormatter.string(from: store.shiftInfo.date))
                                .foregroundColor(.secondary)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            showingCompleteAlert = true
                        }) {
                            Text("Завершить")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding(.horizontal, 16)
                                .padding(.vertical, 10)
                                .background(
                                    Capsule()
                                        .fill(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.red, Color.red.opacity(0.8)]),
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                        )
                                )
                                .shadow(color: Color.red.opacity(0.3), radius: 5, x: 0, y: 3)
                        }
                    }
                    .padding(.horizontal)
                    
                    VStack(spacing: 10) {
                        HStack {
                            Text("Прогресс уборки")
                                .font(.headline)
                            
                            Spacer()
                            
                            Text("\(Int(store.completionPercentage() * 100))%")
                                .font(.headline)
                                .foregroundColor(.blue)
                        }
                        
                        ProgressView(value: store.completionPercentage())
                            .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                            .background(Color(.systemGray6).cornerRadius(10))
                            .frame(height: 10)
                            .animation(.easeInOut(duration: 0.3), value: store.completionPercentage())
                    }
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .fill(Color(.systemBackground))
                            .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
                    )
                    .padding(.horizontal)
                }
                
                HStack {
                    Text("Зоны уборки")
                        .font(.title3)
                        .bold()
                    
                    Spacer()
                }
                .padding(.horizontal)
                .padding(.top, 5)
                
                LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
                    ForEach(Array(store.zones.enumerated()), id: \.element.id) { index, zone in
                        NavigationLink(destination: TaskListView(zone: zone, zoneIndex: index, store: store)) {
                            ZoneCard(zone: zone, isCompleted: store.isZoneCompleted(zone))
                        }
                    }
                }
                .padding(.horizontal)
            }
            .padding(.vertical)
        }
        .navigationTitle("Контроль Уборки")
        .navigationBarTitleDisplayMode(.inline)
        .alert(isPresented: $showingCompleteAlert) {
            Alert(
                title: Text("Завершить смену?"),
                message: Text("Вы уверены, что хотите завершить текущую смену?"),
                primaryButton: .destructive(Text("Завершить")) {
                    store.completeShift()
                },
                secondaryButton: .cancel(Text("Отмена"))
            )
        }
    }
    
    private var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        return formatter
    }
}

struct ZoneCard: View {
    let zone: Zone
    let isCompleted: Bool
    
    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                ZStack {
                    Circle()
                        .fill(zone.color.opacity(0.2))
                        .frame(width: 50, height: 50)
                    
                    Image(systemName: zone.icon)
                        .font(.title2)
                        .foregroundColor(zone.color)
                }
                
                Spacer()
                
                if isCompleted {
                    ZStack {
                        Circle()
                            .fill(Color.green.opacity(0.2))
                            .frame(width: 30, height: 30)
                        
                        Image(systemName: "checkmark")
                            .font(.caption)
                            .foregroundColor(.green)
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 5) {
                Text(zone.name)
                    .font(.headline)
                    .foregroundColor(.primary)
                
                let completedCount = zone.tasks.filter { $0.isCompleted }.count
                Text("\(completedCount) из \(zone.tasks.count) задач")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
        )
    }
}
