import Foundation
import SwiftUI

class TaskStore: ObservableObject {
    @Published var tasks: [CleaningTask] = [
        CleaningTask(title: "Уборка пола", isCompleted: false),
        CleaningTask(title: "Уборка туалета", isCompleted: false),
        CleaningTask(title: "Мойка кальянов", isCompleted: false),
        CleaningTask(title: "Уборка барной стойки", isCompleted: false),
        CleaningTask(title: "Уборка столов", isCompleted: false)
    ]
    
    func toggleTask(_ index: Int) {
        tasks[index].isCompleted.toggle()
        tasks[index].completionTime = tasks[index].isCompleted ? Date() : nil
    }
}
